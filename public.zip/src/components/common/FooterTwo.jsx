import React from "react";

function FooterTwo() {
  return (
    <div className="bg-[#1F2C24] p-3 mt-auto text-xs text-center">
      2025 Copyright © U2U GLOBAL . Designed with by U2U GLOBAL All rights
      reserved
    </div>
  );
}

export default FooterTwo;
