function Footer() {
  return (
    <div className="bg-gradient-to-r from-[#0F0F1D] via-[#102031] to-[#24BB79] p-3">
      2025 Copyright © U2U GLOBAL . Designed with by U2U GLOBAL All rights
      reserved
    </div>
  );
}

export default Footer;
