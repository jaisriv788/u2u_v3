import React from 'react'

function Landing() {
  return (
    <div>Landing</div>
  )
}

export default Landing